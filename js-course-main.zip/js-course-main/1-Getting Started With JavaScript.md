# 1- Getting Started With JavaScript
***
JavaScript is one of the most popular and dynamic programming languages out there.
## Programs in the Videos
```js
console.log("Hello, World");
```
**Output**

```
Hello, World
```
The console.log() prints whatever object that is inside the parentheses `()`.

